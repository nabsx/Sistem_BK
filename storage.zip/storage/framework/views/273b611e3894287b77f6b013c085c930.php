

<?php $__env->startSection('content'); ?>
<div class="student-page">
    <div class="student-breadcrumb">
        <a href="<?php echo e(route('dashboard')); ?>"><span class="material-symbols-outlined">home</span> Beranda</a><span>/</span>
        <a href="<?php echo e(route('dashboard.module', 'students')); ?>">Buku Induk Siswa</a><span>/</span>
        <strong>Detail Siswa: <?php echo e($student->name); ?></strong>
        <span class="student-chip">NIS: <?php echo e($student->nis); ?> · <?php echo e($student->schoolClass?->name ?? 'Kelas belum diatur'); ?></span>
        <span class="sync-status"><i></i> Sinkron terakhir: <?php echo e($student->dapodik_synced_at?->format('d M Y, H:i').' WIB' ?? 'Belum pernah'); ?></span>
    </div>

    <section class="student-hero-card">
        <div class="student-identity">
            <div class="student-photo-wrap">
                <?php if($student->photo_path): ?>
                    <img src="<?php echo e(asset('storage/'.$student->photo_path)); ?>" alt="Foto <?php echo e($student->name); ?>" class="student-photo">
                <?php else: ?>
                    <div class="student-photo student-photo-fallback"><?php echo e(collect(explode(' ', $student->name))->map(fn($part) => substr($part, 0, 1))->take(2)->implode('')); ?></div>
                <?php endif; ?>
                <span class="verified-mark material-symbols-outlined">verified</span>
            </div>
            <div class="student-identity-copy">
                <div class="identity-meta"><span class="status-pill"><?php echo e(ucfirst($student->status)); ?></span><span>NISN: <?php echo e($student->nisn ?: 'Belum diisi'); ?></span></div>
                <h1><?php echo e($student->name); ?></h1>
                <p>Kelas: <strong><?php echo e($student->schoolClass?->name ?? 'Belum diatur'); ?></strong></p>
                <div class="identity-details">
                    <span><span class="material-symbols-outlined">supervisor_account</span> Wali: <strong><?php echo e($student->guardian_name ?: 'Belum diisi'); ?></strong></span>
                    <?php if($student->guardian_phone): ?><a href="tel:<?php echo e($student->guardian_phone); ?>"><span class="material-symbols-outlined">contact_phone</span><?php echo e($student->guardian_phone); ?></a><?php endif; ?>
                </div>
            </div>
        </div>
        <div class="discipline-card">
            <div class="discipline-heading"><div><small>AKUMULASI POIN DISIPLIN</small><strong><?php echo e($totalPoints); ?><em>/ 100 Poin</em></strong></div><span class="risk-badge material-symbols-outlined"><?php echo e($totalPoints >= 60 ? 'warning' : 'check_circle'); ?> <?php echo e($totalPoints >= 60 ? 'Perlu pendampingan' : 'Aman'); ?></span></div>
            <div class="point-meter"><span style="width: <?php echo e(min($totalPoints, 100)); ?>%"></span></div>
            <div class="meter-labels"><span>0–30 Aman</span><span>31–60 Waspada</span><span>75+ Prioritas</span></div>
            <p><span class="material-symbols-outlined">info</span><?php echo e($totalPoints >= 75 ? 'Siswa sudah masuk ambang prioritas pendampingan.' : 'Data poin dihitung langsung dari riwayat pelanggaran.'); ?></p>
        </div>
        <div class="student-actions-panel">
            <div class="student-stats"><div><strong><?php echo e($attendance ?? '—'); ?></strong><small>Kehadiran</small></div><div><strong><?php echo e($violations->count()); ?></strong><small>Pelanggaran</small></div><div><strong><?php echo e($sessions->count()); ?></strong><small>Sesi BK</small></div><div><strong><?php echo e($student->discipline_status ? ucfirst(str_replace('_', ' ', $student->discipline_status)) : '—'); ?></strong><small>Status</small></div></div>
            <div class="student-actions"><a href="<?php echo e(route('dashboard.module', ['module' => 'agenda', 'student' => $student->id])); ?>" class="primary-action"><span class="material-symbols-outlined">add_circle</span> Jadwal Konseling</a><a href="<?php echo e(route('dashboard.module', ['module' => 'violations', 'student' => $student->id])); ?>" class="light-action"><span class="material-symbols-outlined">warning</span> Catat Kasus</a><a href="<?php echo e(route('dashboard.student.export', $student)); ?>" class="icon-action" title="Unduh rekap siswa"><span class="material-symbols-outlined">download</span></a></div>
        </div>
    </section>

    <nav class="student-tabs" aria-label="Bagian buku induk">
        <a class="active" href="#violations"><span class="material-symbols-outlined">assignment_late</span> Riwayat Pelanggaran <b><?php echo e($violations->count()); ?></b></a>
        <a href="#sessions"><span class="material-symbols-outlined">event_busy</span> Riwayat Konseling <b><?php echo e($sessions->count()); ?></b></a>
        <a href="#profile"><span class="material-symbols-outlined">badge</span> Data Profil</a>
    </nav>

    <div class="student-content-grid">
        <section class="student-panel" id="violations">
            <div class="panel-heading"><div><h2>Kronologi Rekam Kedisiplinan</h2><p><?php echo e($violations->count()); ?> kejadian tercatat dari database sekolah.</p></div><a href="<?php echo e(route('dashboard.export.violations')); ?>" class="panel-icon-action" title="Ekspor riwayat"><span class="material-symbols-outlined">download</span></a></div>
            <?php $__empty_1 = true; $__currentLoopData = $violations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $violation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="violation-row"><div class="date-column"><strong><?php echo e($violation->occurred_at?->format('d M Y')); ?></strong><small><?php echo e($violation->occurred_at?->format('H:i')); ?> WIB</small></div><div class="violation-copy"><strong><?php echo e($violation->violationType?->name ?? 'Pelanggaran'); ?></strong><p><?php echo e($violation->notes ?: 'Tidak ada catatan tambahan.'); ?></p></div><span class="points-badge">+<?php echo e($violation->point_snapshot); ?> poin</span><div class="reporter"><strong><?php echo e($violation->reporter?->name ?? 'Tidak diketahui'); ?></strong><small><?php echo e(str_replace('_', ' ', ucfirst($violation->action_status))); ?></small></div></article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state"><span class="material-symbols-outlined">verified</span><strong>Belum ada pelanggaran</strong><p>Riwayat kedisiplinan siswa akan tampil di sini.</p></div>
            <?php endif; ?>
        </section>
        <aside class="student-side-column">
            <section class="student-panel" id="profile"><div class="panel-heading"><div><h2>Data Profil</h2><p>Informasi dasar siswa aktif.</p></div><span class="material-symbols-outlined panel-heading-icon">badge</span></div><dl class="profile-list"><div><dt>NIS</dt><dd><?php echo e($student->nis); ?></dd></div><div><dt>NISN</dt><dd><?php echo e($student->nisn ?: 'Belum diisi'); ?></dd></div><div><dt>Jenis Kelamin</dt><dd><?php echo e($student->gender === 'L' ? 'Laki-laki' : 'Perempuan'); ?></dd></div><div><dt>Tanggal Lahir</dt><dd><?php echo e($student->birth_date?->format('d M Y') ?: 'Belum diisi'); ?></dd></div><div><dt>Hubungan Wali</dt><dd><?php echo e($student->guardian_relation ?: 'Belum diisi'); ?></dd></div></dl></section>
            <section class="student-panel" id="sessions"><div class="panel-heading"><div><h2>Sesi Konseling Terakhir</h2><p>Agenda dan catatan pendampingan.</p></div><span class="session-count"><?php echo e($sessions->count()); ?> sesi</span></div><?php $__empty_1 = true; $__currentLoopData = $sessions->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div class="session-row"><div><strong><?php echo e($session->topic ?: 'Sesi konseling'); ?></strong><small><?php echo e($session->scheduled_at?->format('d M Y, H:i')); ?> · <?php echo e(ucfirst($session->status)); ?></small></div><span class="material-symbols-outlined">chevron_right</span></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="empty-state compact"><span class="material-symbols-outlined">forum</span><p>Belum ada sesi konseling.</p></div><?php endif; ?></section>
        </aside>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Sistem_BK_Mardisiswa\resources\views/dashboard/student.blade.php ENDPATH**/ ?>