

<?php $__env->startSection('content'); ?>
<?php if($module === 'students'): ?>
<div class="student-directory" data-student-directory>
    <div class="student-directory-head">
        <div>
            <div class="student-breadcrumb"><a href="<?php echo e(route('dashboard')); ?>"><span class="material-symbols-outlined">home</span> Beranda</a><span>/</span><strong>Buku Induk Siswa</strong></div>
            <h1>Buku Induk &amp; Database Siswa</h1>
            <p>Data induk rekam perilaku, kedisiplinan, asesmen minat bakat, dan catatan bimbingan konseling seluruh siswa aktif SMA Mardisiswa.</p>
        </div>
        <div class="student-directory-actions"><a class="soft-action" href="<?php echo e(route('dashboard.export.violations')); ?>"><span class="material-symbols-outlined">download</span>Ekspor Data</a><button class="soft-action" type="button"><span class="material-symbols-outlined">sync</span>Sinkron Dapodik</button><a class="primary-action" href="<?php echo e(route('dashboard.student.create')); ?>"><span class="material-symbols-outlined">person_add</span>Tambah Siswa Baru</a></div>
    </div>

    <div class="student-kpis">
        <article class="student-kpi"><div><span>Total Siswa Aktif</span><strong><?php echo e($studentMetrics['total']); ?></strong><small><i class="kpi-dot teal"></i>100% Terdaftar di Dapodik</small></div><span class="kpi-icon blue material-symbols-outlined">groups</span></article>
        <article class="student-kpi"><div><span>Status Aman &amp; Teladan</span><strong class="teal-text"><?php echo e($studentMetrics['safe']); ?></strong><small><b>0 - 30 Poin</b> &nbsp; (<?php echo e($studentMetrics['safePercent']); ?>%)</small></div><span class="kpi-icon teal material-symbols-outlined">verified</span></article>
        <article class="student-kpi"><div><span>Perhatian / Konseling</span><strong class="navy-text"><?php echo e($studentMetrics['attention']); ?></strong><small><b class="blue-label">31 - 60 Poin</b> &nbsp; (<?php echo e($studentMetrics['attentionPercent']); ?>%)</small></div><span class="kpi-icon sky material-symbols-outlined">hearing</span></article>
        <article class="student-kpi"><div><span>Intervensi &amp; Panggilan</span><strong class="red-text"><?php echo e($studentMetrics['intervention']); ?></strong><small><b class="red-label">&gt; 60 Poin</b> &nbsp; (<?php echo e($studentMetrics['interventionPercent']); ?>%)</small></div><span class="kpi-icon red material-symbols-outlined">notifications_active</span></article>
    </div>

    <div class="student-toolbar">
        <label class="student-search"><span class="material-symbols-outlined">search</span><input data-student-search type="search" placeholder="Cari berdasarkan nama atau NIS..." aria-label="Cari siswa"><kbd>CTRL+K</kbd></label>
        <select data-student-filter="class" aria-label="Filter kelas"><option value="">Semua Tingkat</option><?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($class->name); ?>"><?php echo e($class->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
        <select data-student-filter="status" aria-label="Filter status"><option value="">Status Perilaku</option><option value="aman">Aman</option><option value="waspada">Waspada</option><option value="perlu pendampingan">Perlu Pendampingan</option></select>
        <button class="sort-button" type="button" data-sort-points>Poin Tertinggi <span class="material-symbols-outlined">sort</span></button>
        <div class="view-toggle"><button class="is-active" type="button" data-view="table" aria-label="Tampilan tabel"><span class="material-symbols-outlined">view_list</span></button><button type="button" data-view="grid" aria-label="Tampilan kartu"><span class="material-symbols-outlined">grid_view</span></button></div>
    </div>

    <section class="student-table-shell" data-student-table>
        <div class="student-table-head"><span>NO</span><span>PROFIL SISWA &amp; IDENTITAS</span><span>KELAS &amp; ROMBEL</span><span>WALI KELAS</span><span>AKUMULASI<br>POIN PERILAKU</span><span>STATUS BIMBINGAN</span><span></span></div>
        <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php ($points = (int) $row->discipline_points); ?>
        <?php ($status = str_replace('_', ' ', $row->discipline_status ?: ($points > 60 ? 'perlu pendampingan' : ($points > 30 ? 'waspada' : 'aman')))); ?>
        <?php ($initials = collect(explode(' ', trim($row->name)))->filter()->take(2)->map(fn($part) => strtoupper(substr($part, 0, 1)))->implode('')); ?>
        <a class="student-table-row" data-student-row data-name="<?php echo e(strtolower($row->name)); ?>" data-nis="<?php echo e($row->nis); ?>" data-class="<?php echo e($row->schoolClass?->name); ?>" data-status="<?php echo e(strtolower($status)); ?>" data-points="<?php echo e($points); ?>" href="<?php echo e(route('dashboard.student', $row)); ?>"><span class="row-number"><?php echo e(str_pad($rows->firstItem() + $index, 2, '0', STR_PAD_LEFT)); ?></span><span class="student-profile"><span class="student-avatar <?php echo e($points > 60 ? 'danger' : ($points > 30 ? 'warning' : '')); ?>"><?php echo e($initials); ?></span><span><strong><?php echo e($row->name); ?></strong><small>NIS: <?php echo e($row->nis); ?> <em>·</em> NISN: <?php echo e($row->nisn ?: '-'); ?></small></span></span><span><b class="class-chip"><?php echo e($row->schoolClass?->name ?? 'Tanpa kelas'); ?></b></span><span class="homeroom"><strong><?php echo e($row->schoolClass?->homeroomTeacher?->name ?? 'Belum ditentukan'); ?></strong><small><span class="material-symbols-outlined">phone</span> Kontak wali kelas</small></span><span class="point-cell"><strong><?php echo e($points); ?></strong><small><?php echo e($points ? 'Batas: 100' : 'Bebas Catatan'); ?></small><i><b style="width: <?php echo e(min($points, 100)); ?>%"></b></i></span><span><b class="behavior-pill <?php echo e($points > 60 ? 'danger' : ($points > 30 ? 'warning' : 'safe')); ?>"><i></i><?php echo e(ucfirst($status)); ?></b></span><span class="detail-link">Detail Induk <span class="material-symbols-outlined">chevron_right</span></span></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="empty-state">Belum ada data siswa aktif.</div>
        <?php endif; ?>
    </section>
    <div class="student-footer"><span>Menampilkan <strong><?php echo e($rows->firstItem() ?? 0); ?> - <?php echo e($rows->lastItem() ?? 0); ?></strong> dari <strong><?php echo e($rows->total()); ?></strong> siswa</span><span class="sync-status"><i></i> Dapodik sinkron: Hari ini 08:30 WIB</span><div class="student-pagination"><?php echo e($rows->onEachSide(1)->links()); ?></div></div>
</div>
<?php else: ?>
<div class="page-wrap"><section class="panel module-panel"><div class="panel-title"><div><h1><?php echo e($title); ?></h1><p><?php echo e($description); ?></p></div><div class="module-actions"><a class="soft-action" href="<?php echo e(route('dashboard')); ?>"><span class="material-symbols-outlined">arrow_back</span>Dashboard</a></div></div><div class="module-table"><?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if($module === 'violations' || $module === 'reports'): ?><div class="module-row"><strong><?php echo e($row->student?->name ?? 'Siswa tidak ditemukan'); ?></strong><span><?php echo e($row->violationType?->name ?? 'Pelanggaran'); ?></span><span><?php echo e($row->occurred_at?->format('d M Y') ?? '-'); ?></span></div><?php elseif($module === 'agenda' || $module === 'assessments'): ?><div class="module-row"><strong><?php echo e($row->student?->name ?? 'Siswa tidak ditemukan'); ?></strong><span><?php echo e($row->topic ?? 'Sesi konseling'); ?></span><span><?php echo e($row->scheduled_at?->format('d M Y H:i') ?? '-'); ?></span></div><?php else: ?><div class="module-row"><strong><?php echo e($row->name); ?></strong><span><?php echo e($row->category ?? 'Umum'); ?></span><span>Aktif</span></div><?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="empty-state">Belum ada data untuk modul ini.</div><?php endif; ?></div><?php if(method_exists($rows, 'links')): ?><div class="pagination-wrap"><?php echo e($rows->links()); ?></div><?php endif; ?></section></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Sistem_BK_Mardisiswa\resources\views/dashboard/module.blade.php ENDPATH**/ ?>