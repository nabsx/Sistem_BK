

<?php $__env->startSection('content'); ?>
<div class="page-wrap">
    <a href="<?php echo e(route('dashboard')); ?>">← Kembali ke Dashboard</a>
    <section class="panel" style="padding:32px;margin-top:24px">
        <h1>Hasil pencarian siswa</h1>
        <form class="search-box" action="<?php echo e(route('dashboard.search')); ?>">
            <input name="q" value="<?php echo e($term); ?>" placeholder="Nama, NIS, atau NISN">
            <button class="case-button">Cari</button>
        </form>
        <div class="module-table">
            <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a class="module-row" href="<?php echo e(route('dashboard.module', 'students')); ?>"><strong><?php echo e($student->name); ?></strong><span><?php echo e($student->nis); ?> · <?php echo e($student->schoolClass?->name); ?></span><span><?php echo e($student->discipline_points); ?> poin</span></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state">Tidak ada siswa yang cocok dengan pencarian.</div>
            <?php endif; ?>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Sistem_BK_Mardisiswa\resources\views/dashboard/search.blade.php ENDPATH**/ ?>