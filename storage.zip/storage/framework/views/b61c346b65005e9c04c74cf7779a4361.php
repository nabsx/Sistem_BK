

<?php $__env->startSection('content'); ?>
<div class="page-wrap form-page">
    <div class="page-heading-row">
        <div><span class="eyebrow eyebrow-light"><span class="material-symbols-outlined">clinical_notes</span>Buku Induk Siswa</span><h1>Tambah Siswa</h1><p>Tambahkan data siswa baru ke Buku Induk dari database sekolah.</p></div>
        <a class="soft-action" href="<?php echo e(route('dashboard.module', 'students')); ?>"><span class="material-symbols-outlined">arrow_back</span>Kembali</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="form-alert"><strong>Periksa kembali data yang diisi.</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('dashboard.student.store')); ?>" class="student-form">
        <?php echo csrf_field(); ?>
        <section class="form-card"><div class="form-card-heading"><span class="step-number">01</span><div><h2>Identitas Siswa</h2><p>Informasi utama siswa yang tercatat di sekolah.</p></div></div><div class="form-grid">
            <label>NIS<input name="nis" value="<?php echo e(old('nis')); ?>" required></label>
            <label>NISN<input name="nisn" value="<?php echo e(old('nisn')); ?>"></label>
            <label class="span-2">Nama lengkap<input name="name" value="<?php echo e(old('name')); ?>" required></label>
            <label>Jenis kelamin<select name="gender" required><option value="">Pilih</option><option value="L" <?php if(old('gender') === 'L'): echo 'selected'; endif; ?>>Laki-laki</option><option value="P" <?php if(old('gender') === 'P'): echo 'selected'; endif; ?>>Perempuan</option></select></label>
            <label>Tanggal lahir<input type="date" name="birth_date" value="<?php echo e(old('birth_date')); ?>"></label>
        </div></section>
        <section class="form-card"><div class="form-card-heading"><span class="step-number">02</span><div><h2>Kelas dan Wali</h2><p>Hubungkan siswa ke kelas serta kontak wali.</p></div></div><div class="form-grid">
            <label class="span-2">Kelas<select name="school_class_id" required><option value="">Pilih kelas</option><?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($class->id); ?>" <?php if(old('school_class_id') === $class->id): echo 'selected'; endif; ?>><?php echo e($class->name); ?> · <?php echo e($class->academic_year); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <label>Nama wali<input name="guardian_name" value="<?php echo e(old('guardian_name')); ?>"></label>
            <label>Hubungan<input name="guardian_relation" value="<?php echo e(old('guardian_relation')); ?>" placeholder="Ayah / Ibu / Wali"></label>
            <label class="span-2">Nomor telepon wali<input name="guardian_phone" value="<?php echo e(old('guardian_phone')); ?>"></label>
        </div></section>
        <div class="form-actions"><a class="soft-action" href="<?php echo e(route('dashboard.module', 'students')); ?>">Batal</a><button class="primary-action" type="submit"><span class="material-symbols-outlined">save</span>Simpan Siswa</button></div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Sistem_BK_Mardisiswa\resources\views/dashboard/students/create.blade.php ENDPATH**/ ?>